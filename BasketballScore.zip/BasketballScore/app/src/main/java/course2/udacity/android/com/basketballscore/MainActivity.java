package course2.udacity.android.com.basketballscore;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {

    /**
     * variables for team Scores
     * team1Score,team2Score,initialScore
     */
    private int initialScore = 0;
    private int team1Score = 0;
    private int team2Score = 0;
    private TextView team1ScoreView = null;
    private TextView team2ScoreView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        team1ScoreView = (TextView) findViewById(R.id.team2_score_view);
        team2ScoreView = (TextView) findViewById(R.id.team2_score_view);
        initializeTeams();
    }

    private void initializeTeams() {
        team1Score = initialScore;
        team2Score = initialScore;
        updateTeam1Board();
        updateTeam2Board();
    }

    public void resetScore(View view){
        initializeTeams();
    }

    public void updateTeam1Score(View view) {
        String team1Points = ((Button) view).getText().toString();
        team1Score = team1Score + Integer.parseInt(team1Points);
        updateTeam1Board();
    }

    public void updateTeam2Score(View view) {
        String team2Points = ((Button) view).getText().toString();
        team2Score = team2Score + Integer.parseInt(team2Points);
        updateTeam2Board();
    }

    public void updateTeam1Board() {
        TextView team1ScoreView = (TextView) findViewById(R.id.team1_score_view);
        if (team1Score < 10) {
            team1ScoreView.setText("0" + team1Score);
        } else {
            team1ScoreView.setText(String.valueOf(team1Score));
        }
    }

    public void updateTeam2Board() {
        if (team2Score < 10) {
            team2ScoreView.setText("0" + team2Score);
        } else {
            team2ScoreView.setText(String.valueOf(team2Score));
        }
    }
}
